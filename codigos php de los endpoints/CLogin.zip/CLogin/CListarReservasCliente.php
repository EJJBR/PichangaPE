<?php
header("Content-Type: application/json");

// 1. Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
$conexion->set_charset("utf8");

if (!$conexion) {
    die(json_encode(["error" => "Error de conexión"]));
}

// 2. Obtener id_cliente
if (!isset($_POST['id_cliente'])) {
    die(json_encode(["error" => "ID de cliente no recibido"]));
}
$id_cliente = $_POST['id_cliente'];

// 3. Consulta: Traer reservas del cliente con el nombre de la cancha
$query = "SELECT 
            r.id_reserva, 
            c.nombre AS nombre_cancha, 
            DATE(r.fecha_hora_inicio) AS fecha_inicio, 
            DATE_FORMAT(r.fecha_hora_inicio, '%H:%i') AS hora_inicio,
            DATE_FORMAT(r.fecha_hora_fin, '%H:%i') AS hora_fin,
            r.estado AS estado_reserva
          FROM reservas r
          JOIN canchas c ON r.id_cancha = c.id_cancha
          WHERE r.id_reservador = ?
          ORDER BY r.fecha_hora_inicio DESC";

$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$resultado = $stmt->get_result();

$reservas = [];
while ($fila = $resultado->fetch_assoc()) {
    // Para que el cliente vea 'Alquilada' en lugar de 'pagado' si lo deseas
    if($fila['estado_reserva'] == 'pagado') $fila['estado_reserva'] = 'Alquilada';
    $reservas[] = $fila;
}

echo json_encode($reservas);
mysqli_close($conexion);
?>