<?php
// 1. Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
$conexion->set_charset("utf8");

if (!$conexion) {
    die(json_encode(["error" => "Error de conexión: " . mysqli_connect_error()]));
}

// 2. Obtener datos del POST
$usuario = $_POST['usuario'];
$contraseña = $_POST['contraseña'];

// 3. Consulta actualizada: eliminamos el filtro de rol para permitir clientes y dueños
$query = "SELECT * FROM clientes WHERE usuario='$usuario' AND password='$contraseña'";
$resultado = mysqli_query($conexion, $query);

if ($resultado && $resultado->num_rows > 0) {
    // Si existe el usuario, devolvemos todos sus datos (incluyendo el campo 'rol')
    $fila = mysqli_fetch_assoc($resultado);
    echo json_encode($fila);
} else {
    // Si no coincide, error de credenciales
    echo json_encode(["error" => "Usuario o contraseña incorrectos"]);
}

// 4. Cerrar conexión
mysqli_close($conexion);
?>