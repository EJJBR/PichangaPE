<?php
// Establecer encabezado para la respuesta JSON
header("Content-Type: application/json");

// 1. Conexión a la base de datos (usando los datos que me diste)
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
$conexion->set_charset("utf8");

// Verificar si la conexión falló
if (!$conexion) {
    // Si falla, se devuelve un error en JSON y se detiene el script
    die(json_encode(["error" => "Error de conexión a la base de datos."]));
}

// 2. Verificar que se recibió el ID del dueño
if (!isset($_POST['id_dueno'])) {
    die(json_encode(["error" => "Parámetro 'id_dueno' no recibido."]));
}

$id_dueno = $_POST['id_dueno'];

// 3. Preparar la consulta SQL para obtener las canchas de ese dueño
// Se seleccionan los campos que el RecyclerView espera
$query = "SELECT id_cancha, nombre, direccion, precio_por_hora FROM canchas WHERE id_dueno = ?";

$stmt = $conexion->prepare($query);

// Si la preparación falla, se devuelve un error
if ($stmt === false) {
    die(json_encode(["error" => "Error al preparar la consulta SQL."]));
}

// 4. Ejecutar la consulta de forma segura
$stmt->bind_param("i", $id_dueno); // "i" porque id_dueno es un entero
$stmt->execute();
$resultado = $stmt->get_result();

// 5. Recopilar los resultados en un array
$canchas = [];
while ($fila = $resultado->fetch_assoc()) {
    $canchas[] = $fila;
}

// 6. Formatear la respuesta como espera la app
// Se crea un objeto JSON principal con una clave "canchas" que contiene la lista
$respuesta = ["canchas" => $canchas];
echo json_encode($respuesta);

// 7. Cerrar los recursos
$stmt->close();
mysqli_close($conexion);
?>