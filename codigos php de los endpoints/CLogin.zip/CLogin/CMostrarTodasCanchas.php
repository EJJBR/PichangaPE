<?php
header("Content-Type: application/json");

// 1. Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
$conexion->set_charset("utf8");

if (!$conexion) {
    die(json_encode(["error" => "Error de conexión: " . mysqli_connect_error()]));
}

// 2. Consulta SQL con JOIN para traer datos del Dueño y Disponibilidad
// Traemos: datos de la cancha + numYape y numTransfer del dueño (tabla clientes)
$query = "SELECT 
            c.id_cancha, 
            c.nombre, 
            c.direccion, 
            c.precio_por_hora, 
            c.horasDisponibles, 
            c.fechas_abiertas,
            cl.numYape, 
            cl.numTransfer 
          FROM canchas c
          JOIN clientes cl ON c.id_dueno = cl.id_cliente
          WHERE c.estado = 'activa'";

$resultado = mysqli_query($conexion, $query);

$canchas = [];
while ($fila = mysqli_fetch_assoc($resultado)) {
    $canchas[] = $fila;
}

// 3. Devolver los datos en formato JSON
echo json_encode(["canchas" => $canchas]);

mysqli_close($conexion);
?>