<?php
header("Content-Type: application/json");

// 1. Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
$conexion->set_charset("utf8");

if (!$conexion) {
    die(json_encode(["error" => "Error de conexión: " . mysqli_connect_error()]));
}

// 2. Verificar parámetros
if (!isset($_POST['id_reservador']) || !isset($_POST['id_cancha'])) {
    die(json_encode(["error" => "Faltan parámetros obligatorios"]));
}

// 3. Obtener datos
$id_reservador = $_POST['id_reservador'];
$id_cancha = $_POST['id_cancha'];
$inicio = $_POST['fecha_hora_inicio']; // Formato esperado: YYYY-MM-DD HH:mm:ss
$fin = $_POST['fecha_hora_fin'];
$precio = $_POST['precio_total'];
$voucher = $_POST['voucher_pago']; // URL de ImgBB
$estado = 'pendiente';
$validado = 0;

// 4. Insertar en la base de datos
$query = "INSERT INTO reservas (id_reservador, id_cancha, fecha_hora_inicio, fecha_hora_fin, precio_total, voucher_pago, estado, validado) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conexion->prepare($query);
if ($stmt) {
    $stmt->bind_param("iissdssi", $id_reservador, $id_cancha, $inicio, $fin, $precio, $voucher, $estado, $validado);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Reserva realizada con éxito. Espere la aprobación del dueño."]);
    } else {
        echo json_encode(["error" => "Error al guardar la reserva: " . $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(["error" => "Error en la preparación de la consulta"]);
}

mysqli_close($conexion);
?>