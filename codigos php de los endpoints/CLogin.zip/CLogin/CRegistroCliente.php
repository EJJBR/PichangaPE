<?php
header("Content-Type: application/json");

// 1. Conexión a la base de datos
$host = "sql.freedb.tech";
$usuario_db = "freedb_PichangaPEUser";
$password_db = "M9h6Ym?ntb7JSNC";
$basedatos = "freedb_pichangaPE";
$puerto = 3306;

$conexion = mysqli_connect($host, $usuario_db, $password_db, $basedatos, $puerto);
$conexion->set_charset("utf8");

if (!$conexion) {
    die(json_encode(["error" => "Error de conexión: " . mysqli_connect_error()]));
}

// 2. Verificar que se recibieron los parámetros necesarios
if (
    !isset($_POST['nombre']) || !isset($_POST['apellido']) || 
    !isset($_POST['numeroCel']) || !isset($_POST['correo']) ||
    !isset($_POST['documento']) || !isset($_POST['tipoDoc']) ||
    !isset($_POST['fechaNac']) || !isset($_POST['usuario']) || 
    !isset($_POST['password'])
) {
    die(json_encode(["error" => "Faltan parámetros obligatorios."]));
}

// 3. Obtener los datos del POST
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$numeroCel = $_POST['numeroCel'];
$correo = $_POST['correo'];
$documento = $_POST['documento'];
$tipoDoc = $_POST['tipoDoc'];
$fechaNac = $_POST['fechaNac'];
$usuario = $_POST['usuario'];
$password = $_POST['password'];
$rol = "cliente"; // Rol automático

// 4. Validar si el usuario o correo ya existen
$checkQuery = "SELECT id_cliente FROM clientes WHERE usuario = ? OR correo = ?";
$checkStmt = $conexion->prepare($checkQuery);
$checkStmt->bind_param("ss", $usuario, $correo);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
    die(json_encode(["error" => "El usuario o correo ya se encuentra registrado."]));
}
$checkStmt->close();

// 5. Preparar la inserción
$query = "INSERT INTO clientes (nombre, apellido, numeroCel, correo, documento, tipoDoc, fechaNac, usuario, password, rol) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conexion->prepare($query);

if ($stmt) {
    $stmt->bind_param("ssssssssss", $nombre, $apellido, $numeroCel, $correo, $documento, $tipoDoc, $fechaNac, $usuario, $password, $rol);

    if ($stmt->execute()) {
        echo json_encode(["success" => "Usuario registrado correctamente."]);
    } else {
        echo json_encode(["error" => "Error al registrar: " . $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(["error" => "Error en la preparación de la consulta."]);
}

mysqli_close($conexion);
?>
