<?php
// Datos de conexión
$host = "sql.freedb.tech";
$usuario = "freedb_PichangaPEUser";
$password = "M9h6Ym?ntb7JSNC"; // tu contraseña
$basedatos = "freedb_pichangaPE";
$puerto = 3306;

// Crear conexión
$conn = new mysqli($host, $usuario, $password, $basedatos, $puerto);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Opcional: establecer codificación
$conn->set_charset("utf8");

// Si quieres probar que conecta:
echo "Conexión exitosa";
?>