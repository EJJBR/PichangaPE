<?php
// Establecemos que la respuesta será texto plano (la app espera "success")
header("Content-Type: text/plain");

// 1. Conexión a la base de datos
$host = "sql.freedb.tech";
$usuario_db = "freedb_PichangaPEUser";   
$password_db = "M9h6Ym?ntb7JSNC";
$basedatos = "freedb_pichangaPE";
$puerto = 3306;

$conexion = mysqli_connect($host, $usuario_db, $password_db, $basedatos, $puerto);
$conexion->set_charset("utf8");

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// 2. Verificar que se recibieron los parámetros necesarios
if (
    !isset($_POST['id_cancha']) ||
    !isset($_POST['nombre']) ||
    !isset($_POST['direccion']) ||
    !isset($_POST['precio_por_hora']) ||
    !isset($_POST['tipoCancha']) ||
    !isset($_POST['horasDisponibles']) ||
    !isset($_POST['fechas_abiertas'])
) {
    die("Error: Faltan parámetros para actualizar.");
}

// 3. Obtener los datos
$id_cancha = $_POST['id_cancha'];
$nombre = $_POST['nombre'];
$direccion = $_POST['direccion'];
$precio_por_hora = $_POST['precio_por_hora'];
$tipoCancha = $_POST['tipoCancha'];
$horasDisponibles = $_POST['horasDisponibles'];
$fechas_abiertas = $_POST['fechas_abiertas'];

// 4. Preparar la consulta SQL de actualización (UPDATE)
$query = "UPDATE canchas SET 
            nombre = ?, 
            direccion = ?, 
            precio_por_hora = ?, 
            tipoCancha = ?, 
            horasDisponibles = ?, 
            fechas_abiertas = ? 
          WHERE id_cancha = ?";

$stmt = $conexion->prepare($query);

if ($stmt) {
    // "sssdssi" indica los tipos de datos: s (string), d (double/decimal), i (integer)
    $stmt->bind_param("ssdsssi", $nombre, $direccion, $precio_por_hora, $tipoCancha, $horasDisponibles, $fechas_abiertas, $id_cancha);

    // 5. Ejecutar y responder
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "Error al actualizar: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Error en la preparación: " . $conexion->error;
}

// 6. Cerrar conexión
mysqli_close($conexion);
?>