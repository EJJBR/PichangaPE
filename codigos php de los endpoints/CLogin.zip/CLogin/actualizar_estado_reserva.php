<?php
header("Content-Type: application/json");

// 1. Conexión
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
$conexion->set_charset("utf8");

if (!$conexion) {
    die(json_encode(["error" => "Error de conexión"]));
}

// 2. Parámetros
$id_reserva = $_POST['id_reserva'];
$nuevo_estado = $_POST['estado'];

// 3. ACTUALIZAR (Esto es lo que dices que ya funciona)
$query_update = "UPDATE reservas SET estado = ? WHERE id_reserva = ?";
$stmt = $conexion->prepare($query_update);
$stmt->bind_param("si", $nuevo_estado, $id_reserva);
$exito = $stmt->execute();
$stmt->close();

if ($exito) {
    // 4. ¡ESTO ES LO QUE FALTA! Buscamos el ID del dueño para devolverlo a la App
    $query_dueno = "SELECT cl.id_cliente, cl.nombre, cl.apellido 
                    FROM reservas r 
                    JOIN canchas c ON r.id_cancha = c.id_cancha 
                    JOIN clientes cl ON c.id_dueno = cl.id_cliente 
                    WHERE r.id_reserva = ?";
    
    $stmt_d = $conexion->prepare($query_dueno);
    $stmt_d->bind_param("i", $id_reserva);
    $stmt_d->execute();
    $res = $stmt_d->get_result();
    
    if ($fila = $res->fetch_assoc()) {
        // Devolvemos success + los datos del dueño
        echo json_encode([
            "success" => "Reserva actualizada correctamente",
            "id_cliente" => $fila['id_cliente'],
            "nombre" => $fila['nombre'],
            "apellido" => $fila['apellido']
        ]);
    } else {
        echo json_encode(["error" => "Reserva actualizada, pero no se encontró al dueño."]);
    }
    $stmt_d->close();
} else {
    echo json_encode(["error" => "Error al actualizar la base de datos."]);
}

mysqli_close($conexion);
?>