<?php
// Encabezados para permitir la conexión desde la app
header("Content-Type: text/plain");
header("Access-Control-Allow-Origin: *");

// 1. Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
$conexion->set_charset("utf8");

// Verificar si la conexión falló
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// 2. Obtener los datos enviados desde la app
$id_dueno = $_POST['id_dueno'];
$nombre = $_POST['nombre'];
$direccion = $_POST['direccion'];
$precio_por_hora = $_POST['precio_por_hora'];
$tipoCancha = $_POST['tipoCancha'];
$horasDisponibles = $_POST['horasDisponibles'];
$fechas_abiertas = $_POST['fechas_abiertas'];
$estado = $_POST['estado'];

// 3. Crear la consulta SQL para insertar la cancha
// Nota: Los valores de texto se encierran en comillas simples
$query = "INSERT INTO canchas (id_dueno, nombre, direccion, precio_por_hora, tipoCancha, horasDisponibles, fechas_abiertas, estado) VALUES ('$id_dueno', '$nombre', '$direccion', '$precio_por_hora', '$tipoCancha', '$horasDisponibles', '$fechas_abiertas', '$estado')";

// 4. Ejecutar la consulta y enviar la respuesta que la app espera
if (mysqli_query($conexion, $query)) {
    echo "success"; // Respuesta si el registro fue exitoso
} else {
    echo "Error: " . mysqli_error($conexion); // Respuesta si hubo un error
}

// 5. Cerrar la conexión
mysqli_close($conexion);
?>