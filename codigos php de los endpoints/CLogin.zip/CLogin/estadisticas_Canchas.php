<?php
// Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
if (!$conexion) {
    echo json_encode(["error" => "Error al conectar con la base de datos"]);
    exit();
}
$conexion->set_charset("utf8");

// Verificar que se haya enviado id_cliente
if (!isset($_POST['id_cliente']) || empty($_POST['id_cliente'])) {
    echo json_encode(["error" => "No se ha proporcionado id_cliente"]);
    exit();
}

$id_cliente = $_POST['id_cliente'];

// Consulta corregida: Ahora busca 'alquilada' en lugar de 'pagado'
$query = "SELECT 
    c.id_cancha,
    c.nombre,
    IFNULL(SUM(CASE WHEN r.estado = 'alquilada' THEN r.precio_total ELSE 0 END), 0) AS ganancias,
    COUNT(r.id_reserva) AS total_reservas,
    COUNT(CASE WHEN r.estado = 'alquilada' THEN 1 ELSE NULL END) AS total_reservas_pagadas
FROM 
    canchas c
LEFT JOIN 
    reservas r ON c.id_cancha = r.id_cancha
WHERE
    c.id_dueno = ?
GROUP BY 
    c.id_cancha, c.nombre";

$stmt = $conexion->prepare($query);
if (!$stmt) {
    echo json_encode(["error" => "Error en la preparación de la consulta"]);
    exit();
}

$stmt->bind_param("s", $id_cliente);
$stmt->execute();
$resultado = $stmt->get_result();

// Recopilar los datos
$datos = array();
while ($fila = mysqli_fetch_assoc($resultado)) {
    $datos[] = $fila;
}

// Retornar los datos en formato JSON
echo json_encode($datos);

$stmt->close();
mysqli_close($conexion);
?>