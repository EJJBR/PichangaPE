<?php
// 1. Verifica que se ha recibido el parámetro "id_reserva" vía POST
if (!isset($_POST['id_reserva']) || empty($_POST['id_reserva'])) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'error' => 'Falta el parámetro "id_reserva"']);
    exit;
}
$id_reserva = $_POST['id_reserva'];

// 2. Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
if (!$conexion) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['success' => false, 'error' => 'Error al conectar con la base de datos']);
    exit;
}
$conexion->set_charset("utf8");

// 3. Consulta para obtener el voucher_pago correspondiente al id_reserva
$query = "SELECT voucher_pago FROM reservas WHERE id_reserva = ?";
$stmt = mysqli_prepare($conexion, $query);
if (!$stmt) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['success' => false, 'error' => 'Error en la preparación de la consulta']);
    exit;
}

mysqli_stmt_bind_param($stmt, "i", $id_reserva);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $voucher_pago);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);
mysqli_close($conexion);

// Verifica que se obtuvo un voucher
if (empty($voucher_pago)) {
    header('HTTP/1.1 404 Not Found');
    echo json_encode(['success' => false, 'error' => 'No se encontró voucher para el id_reserva proporcionado']);
    exit;
}

// 4. Valida que voucher_pago sea una URL válida
if (!filter_var($voucher_pago, FILTER_VALIDATE_URL)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'error' => 'El voucher_pago no es una URL válida']);
    exit;
}

// 5. Devuelve la URL del voucher en formato JSON
header('Content-Type: application/json');
echo json_encode(['success' => true, 'image_url' => $voucher_pago]);
?>
