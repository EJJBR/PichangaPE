<?php
header("Content-Type: application/json");

// 1. Conexión a la base de datos
$host = "sql.freedb.tech";
$usuario_db = "freedb_PichangaPEUser";
$password_db = "M9h6Ym?ntb7JSNC";
$basedatos = "freedb_pichangaPE";
$puerto = 3306;

$conexion = mysqli_connect($host, $usuario_db, $password_db, $basedatos, $puerto);
$conexion->set_charset("utf8");

if (!$conexion) {
    die(json_encode(["error" => "Error de conexión: " . mysqli_connect_error()]));
}

// 2. Verificar el parámetro id_cancha (se recibe por GET según tu Java)
if (!isset($_GET['id_cancha'])) {
    die(json_encode(["error" => "No se proporcionó el id_cancha"]));
}

$id_cancha = $_GET['id_cancha'];

// 3. Obtener Datos de la Cancha y el Dueño (Query 1)
$queryCancha = "SELECT 
    c.nombre AS nombre_cancha, 
    c.direccion, 
    c.precio_por_hora, 
    c.tipoCancha, 
    c.horasDisponibles, 
    c.fechas_abiertas, 
    c.estado AS estado_cancha,
    cl.nombre AS nombre_dueno, 
    cl.apellido AS apellido_dueno, 
    cl.numeroCel AS celular_dueno, 
    cl.correo AS correo_dueno
FROM canchas c
JOIN clientes cl ON c.id_dueno = cl.id_cliente
WHERE c.id_cancha = ?";

$stmt1 = $conexion->prepare($queryCancha);
$stmt1->bind_param("i", $id_cancha);
$stmt1->execute();
$resCancha = $stmt1->get_result();

if ($resCancha->num_rows === 0) {
    die(json_encode(["error" => "Cancha no encontrada"]));
}

$datosCancha = $resCancha->fetch_assoc();

// 4. Obtener Lista de Reservas (Query 2)
$queryReservas = "SELECT 
    fecha_hora_inicio AS inicio, 
    fecha_hora_fin AS fin, 
    precio_total AS precio, 
    estado 
FROM reservas 
WHERE id_cancha = ? 
ORDER BY fecha_hora_inicio DESC";

$stmt2 = $conexion->prepare($queryReservas);
$stmt2->bind_param("i", $id_cancha);
$stmt2->execute();
$resReservas = $stmt2->get_result();

$listaReservas = [];
while ($row = $resReservas->fetch_assoc()) {
    $listaReservas[] = $row;
}

// 5. Enviar respuesta consolidada
echo json_encode([
    "cancha" => $datosCancha,
    "reservas" => $listaReservas
]);

// Cerrar conexiones
$stmt1->close();
$stmt2->close();
mysqli_close($conexion);
?>