<?php
// Conexión a la base de datos
$conexion = mysqli_connect("sql.freedb.tech", "freedb_PichangaPEUser", "M9h6Ym?ntb7JSNC", "freedb_pichangaPE", "3306");
if (!$conexion) {
    die(json_encode(["error" => "Error al conectar con la base de datos"]));
}
$conexion->set_charset("utf8");

// Verificar que se haya enviado el parámetro id_reserva
if (!isset($_POST['id_reserva'])) {
    echo json_encode(["error" => "No se ha enviado el parámetro id_reserva"]);
    exit;
}

$id_reserva = $_POST['id_reserva'];

// Preparar la consulta SQL utilizando prepared statement para evitar inyección SQL
$query = "SELECT 
    DATE(r.fecha_hora_inicio) AS fecha,
    DATE_FORMAT(r.fecha_hora_inicio, '%H:%i') AS hora_inicio,
    DATE_FORMAT(r.fecha_hora_fin, '%H:%i') AS hora_fin,
    cl.id_cliente,
    cl.nombre AS nombre_reservador,
    cl.apellido AS apellido_reservador,
    cl.numeroCel AS celular,
    r.estado AS estado_reserva
FROM reservas r
JOIN clientes cl ON r.id_reservador = cl.id_cliente
WHERE r.id_reserva = ?";

$stmt = $conexion->prepare($query);
if (!$stmt) {
    echo json_encode(["error" => "Error en la preparación de la consulta"]);
    exit;
}

// Se asume que id_reserva es un entero
$stmt->bind_param("i", $id_reserva);
$stmt->execute();
$resultado = $stmt->get_result();

// Verificar si se obtuvo algún resultado
if($resultado->num_rows > 0) {
    $datos = $resultado->fetch_assoc();
    echo json_encode($datos);
} else {
    echo json_encode(["error" => "No se encontró la reserva con el id proporcionado"]);
}

// Cerrar conexiones
$stmt->close();
mysqli_close($conexion);
?>
